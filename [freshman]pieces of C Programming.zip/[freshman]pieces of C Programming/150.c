#include <stdio.h>
int main (void)
{
    int i, j, k, max_index, n;
    struct student{
        int number;
        char name[20];
        int score[3];
        int sum;
    }stu[10];

    scanf("%d", &n);
/*---------*/
    printf("�ܷ���ߵ�ѧ����: %s��%d��\n", stu[max_index].name, stu[max_inde