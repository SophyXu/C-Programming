#include <stdio.h>
double fun(int m);
int main(void)
{
    int i, m, n;
    int repeat, ri;
    double sum;

    scanf("%d",&repeat);
    for(ri = 1; ri <= repeat; ri++){
	scanf("%d%d", &m, &n);
	sum=0;
	 for(i=m;i<=n;i++)
	 {
	    sum=sum+fun(i);

	 }
         printf("sum = %.6f\n", sum);    }
}
double fun(int m)
{
   double sum;
   sum=0;
   sum=m*m+1.0/m;
   return sum;
}