#include<stdio.h>
#include<stdlib.h>

typedef struct Node *PtrToNode;
struct Node{
	long coef;
	long expo;
	PtrToNode next;
};
typedef PtrToNode Polynomial;

int SIZE = sizeof(struct Node);

Polynomial creat();
Polynomial add(Polynomial nodex, Polynomial nodey);
void print(Polynomial node);
void LinkSort(Polynomial);
void hebing(Polynomial);

int main()
{
	Polynomial nodex, nodey;
	Polynomial AddResult;
	
	nodex = nodey = NULL;
	AddResult = NULL;
	
	nodex = creat();
	
	nodey = creat();
	
        print(nodex);
        print(nodey);

	AddResult = add(nodex, nodey);
        print(AddResult);
	
	LinkSort(AddResult);
        print(AddResult);	

	hebing(AddResult);
	
        print(AddResult);	
	
	return 0;
}

Polynomial creat()
{
	Polynomial temp, head;
        long Expo, Coef;
        int flag = 0;

        temp = (Polynomial)malloc(SIZE);
	head = (Polynomial)malloc(SIZE);
	head->expo = head->coef = 0;
        head->next = temp;
        printf("Input two numbers:\n");
        while(1){
                scanf("%ld %ld", &Expo, &Coef);
                flag++;
		temp->expo = Expo;
                temp->coef = Coef;
                if(Expo == 0 && Coef == 0){
                    break;    
                }
		temp->next = (Polynomial)malloc(SIZE);
		temp = temp->next;
	}
        if(flag)
            temp->next = NULL;
        else
            head->next = NULL;
	return head;
}

Polynomial add(Polynomial nodex, Polynomial nodey)
{
	Polynomial m1 = nodex->next, m2 = nodey->next, HEAD, temp;
	temp = (Polynomial)malloc(SIZE);
	HEAD = temp;
	int flag = 1;
	if(nodex->next == NULL)
		return nodey;
	if(nodey->next == NULL)
		return nodex;
	while(m1 != NULL && m2 != NULL){		
		if(m1->coef > m2->coef){
			temp->coef = m1->coef;
			temp->expo = m1->expo;
			m1 = m1->next;
		}
		else if(m2->coef > m1->coef){
			temp->coef = m2->coef;
			temp->expo = m2->expo;
			m2 = m2->next;
		}
		else if(m2->coef == m1->coef && (m1->next != NULL || m2->next != NULL)){
			temp->coef = m1->coef;
			temp->expo = m1->expo + m2->expo;
			m1 = m1->next;
			m2 = m2->next;
		}
		else{
			flag = 0;
			break;
		}
		temp->next = (Polynomial)malloc(SIZE);
		temp = temp->next;
	}
	if(flag == 0){
		temp->coef = m1->coef;
		temp->expo = m1->expo + m2->expo;
		temp->next = NULL;
		return HEAD;
	}
	while(m1 != NULL && m1->next != NULL){		
		temp->coef = m1->coef;
		temp->expo = m1->expo;
		m1 = m1->next;
		temp->next = (Polynomial)malloc(SIZE);
		temp = temp->next;
	}
	if(m1 != NULL){
		temp->coef = m1->coef;
		temp->expo = m1->expo;
		temp->next = NULL;
	}
	while(m2 != NULL && m2->next != NULL){		
		temp->coef = m2->coef;
		temp->expo = m2->expo;
		m2 = m2->next;
		temp->next = (Polynomial)malloc(SIZE);
		temp = temp->next;
	}
	if(m2 != NULL){
		temp->coef = m2->coef;
		temp->expo = m2->expo;
		temp->next = NULL;
	}
        temp = (Polynomial)malloc(SIZE);
        temp->expo = temp->coef = 0;
        temp->next = HEAD;
	return temp;
}

void print(Polynomial node)
{
	Polynomial temp = node->next;
	int flag = 0;
	if(node->next == NULL){
		printf("0 0\n");
		return;
	}
	while(temp->next != NULL){
		if(temp->expo != 0){
			printf("%ld %ld ", temp->expo, temp->coef);
			flag = 1;
		}
		temp = temp->next;
	}
	if(temp->expo != 0){
		printf("%ld %ld", temp->expo, temp->coef);
		flag = 1;
	}
	if(flag == 0)
		printf("0 0");
	printf("\n");
}

void LinkSort(Polynomial head)
{
	Polynomial temp = head->next, m1, m2, p, max;
	long a, b;
	if(head->next == NULL)
		return;
	while(temp != NULL){
		max = temp;
		m2 = temp;
		while(m2->next != NULL){
			if(max->coef < m2->coef)
				max = m2;
			m2 = m2->next;
		}
		/*交换*/
		a = max->coef;
		b = max->expo;
		max->coef = temp->coef;
		max->expo = temp->expo;
		temp->coef = a;
		temp->expo = b;
		temp = temp->next;
	}
}

void hebing(Polynomial head)
{
	Polynomial temp = head->next, p, m;
	if(head->next == NULL)
		return;
	while(temp->next->next != NULL){
		m = temp;
		while(m->coef == m->next->coef){
			m->expo += m->next->expo;
			p = m->next;
			m->next = p->next;
			if(p != NULL)
			    free(p);
		}
		temp = temp->next;
	}
}


/*List ReverseList( List L )
{
    Position CurrentPos, NextPos, PreviousPos;
    PreviousPos = NULL;
    CurrentPos = L;
    NextPos = L->Next;
    while( NextPos != NULL ){
        CurrentPos->Next = PreviousPos;
        PreviousPos = CurrentPos;
        CurrentPos = NextPos;
        NextPos = NextPos->Next;
    }
    CurrentPos->Next = PreviousPos;
    return CurrentPos;
}
*/
