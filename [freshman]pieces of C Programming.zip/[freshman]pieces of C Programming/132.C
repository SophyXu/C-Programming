#include <stdio.h>
void mov(int *x, int n, int m);
int main(void)
{
    int i, m, n;
    int a[80];

    scanf("%d%d", &n, &m);
    for(i = 0; i < n; i++)
	scanf("%d", &a[i]);
    mov(a, n, m);
    printf("After move: ");
    for(i = 0; i < n; i++)
         printf("%d ", a[i]);
    printf("\n");
    return 0;
}
void mov(int *x, int n, int m)
{
    int t[80];
    int i, j=0;
    m=m%n;
    for(i=n-m;i<=n-1;i++)
    {
	t[j]=x[i];
	j++;
    }
    for(i=n-1;i>=m;i--)
	x[i]=x[i-m];
    for(i=0;i<=m-1;i++)
	x[i]=t[i];
}
