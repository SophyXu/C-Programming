#include <stdio.h>
int main(void)
{
    int flag, i, n;
    int repeat, ri;
    double item, sum;

    scanf("%d", &repeat);
    for(ri = 1; ri <= repeat; ri++){
	scanf("%d", &n);
	sum=0;
	flag=1;
	 for(i=1;i<=n;i++)
	 {
	      sum=sum+flag*1.0*i/(2*i-1);
	      flag=-flag;
	 }
	printf("sum = %.3f\n", sum);
     }
}