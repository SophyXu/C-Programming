#include <stdio.h>
int main( )
{
    int i, index, n, temp;
    int repeat, ri;
    int a[10];

    scanf("%d", &repeat);
    for(ri = 1; ri <= repeat; ri++){
        scanf("%d", &n);
        for(i = 0; i < n; i++)
            scanf("%d", &a[i]);
        index=0;
		for(i=1;i<n;i--){
			if(a[index]<=a[i])
				index=i;
		}
			temp=a[index];
			a[index]=a[n-1];
			a[n-1]=temp;
			printf("max = %d, index = %d\n",a[n-1],index);
			
        for(i = 0; i < n; i++)
        printf("%d ", a[i]);
        printf("\n");
    }
}
