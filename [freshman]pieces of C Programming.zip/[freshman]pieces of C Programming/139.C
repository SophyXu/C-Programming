#include<stdio.h>
#include<string.h>
void strmcpy(char *s,char *t, int m);
void main()
{
    char s[80], t[80];
    int m;
    int repeat, ri;

    scanf("%d", &repeat);
    getchar();
    for(ri = 1; ri <= repeat; ri++){
        gets(t);
        scanf("%d", &m);
	getchar();
	if(strlen(t) < m)
            printf("error input");
        else{
	     strmcpy(s,t,m);
            puts(s);
	}
    }
}
void strmcpy(char *s,char *t, int m)
{
    int i=0;
    int l=strlen(t);
    for(i=0;i<=l-m+1;i++)
    {
	s[i]=t[m-1+i];
    }
    s[i]='\0';
}
