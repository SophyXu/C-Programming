#include <stdio.h>
int mirror(char *p);
void main()
{
    char s[80];
    int repeat, ri;

    scanf("%d", &repeat);
    getchar();
    for(ri = 1; ri <= repeat; ri++){
	 gets(s);
        if(mirror(s) != 0)
      	    printf("YES\n");
        else
            printf("NO\n");
    }
}
int mirror(char *p)
{
   int l=0,i;
   int m, flag=1;
   for(i=0;i<80;i++)
   {
       if(p[i]=='\0')
	  break;
       l++;
   }
   for(m=0;m<l/2;m++)
   {
      if(p[m]!=p[l-m-1])
       {
	  flag=0;
	  break;
       }
   }
    return flag;
}