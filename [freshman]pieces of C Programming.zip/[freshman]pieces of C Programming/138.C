#include<stdio.h>
#include<math.h>
main()
{
    int n, i=0, j=0, p, q;
    int a, b;
    scanf("%d %d %d", &n, &a, &b);
    p=a;
    q=b;
    while(p!=0)
    {
       i++;
       p=p/10;
    }
    while(q!=0)
    {
       j++;
       q=q/10;
    }
    p=a/pow(10,(i-n));
    q=b/pow(10,(i-n));
    if(i==j)
    {
	   if(p==q)
	      {
		  printf("YES");
		  printf("  0.%d*10^%d",p, i);
	      }
	   else
	      {
		 printf("NO   0.%d*10^%d  0.%d*10^%d", p, i , q, j);
	      }

    }
    else
    {
       printf("NO  0.%d*10^%d  0.%d*10^%d", p, i, q, j);
    }
}
