#include<stdio.h>
int main(void)
{
    int count=0, i, m, n, no, j, flag=1;
    int num[50];
    int *p;

    scanf("%d%d", &n, &m);
    for(i = 0; i < n; i++)
	num[i] = i+1;
    i=0;
    for(j=1;j<=n;j++)
    {
      flag=1;
      while(flag)
      {
	 if(num[i%n]!=0)
	   count++;
	 if(count%m==0)
	   {
	     num[i%n]=0;
	     flag=0;
	    }
	 i++;
      }
    }
    for(i=0 ;i<=n;i++)
    {
       if(num[i]!=0)
       {
	  p=&num[i];
	  break;
       }
    }
    printf("Last No is: %d\n", *p);
}